/*
package com.example.limdoeun.refrigerator_graduation;

import android.hardware.Camera;
import android.os.Build;
import android.support.annotation.RequiresApi;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.NetworkResponse;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.bikomobile.multipart.Multipart;

import org.json.JSONArray;
import org.json.JSONException;

import java.io.IOException;
import java.nio.charset.StandardCharsets;

public class ImageActivity extends AppCompatActivity implements SurfaceHolder.Callback, Camera.PreviewCallback {

    private String TAG = "web_demo";

    private SurfaceView surfaceViewCamera;
    private SurfaceHolder surfaceHolder;
    private Camera camera;
    private Button captureBtn;
    private TextView textView;
    private static byte[] bytesData = null;

    private String uploadURL = "http://192.168.1.17:5000/classify_upload_json"; // ip주소 변경

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_image);

        surfaceViewCamera = (SurfaceView) findViewById(R.id.surfaceViewCamera);
        surfaceHolder = surfaceViewCamera.getHolder();
        surfaceHolder.addCallback(this);
        surfaceHolder.setType(SurfaceHolder.SURFACE_TYPE_PUSH_BUFFERS);

        textView = (TextView) findViewById(R.id.textView);

        captureBtn = (Button) findViewById(R.id.captureButton);
        captureBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                captureBtn.setEnabled(false);
                camera.takePicture(null, null, new Camera.PictureCallback() {

                    @Override
                    public void onPictureTaken(byte[] bytes, Camera camera) {
                        bytesData = bytes;
                        Log.d(TAG, "sendToData call : " + bytesData.length);

                        Toast.makeText(getApplicationContext(), "Send to Data, waiting...", Toast.LENGTH_SHORT).show();
                        Multipart multipart = new Multipart(getApplicationContext());
                        multipart.addFile("image/jpeg", "imagefile", "temp.jpg", bytes);
                        multipart.launchRequest(uploadURL, new Response.Listener<NetworkResponse>() {
                            @Override
                            public void onResponse(NetworkResponse response) {
                                Toast.makeText(getApplicationContext(), "Success", Toast.LENGTH_LONG).show();
                                String resText = new String(response.data, StandardCharsets.UTF_8);
                                try {
                                    JSONArray jarray = new JSONArray(resText);

                                    //Log.d(TAG, jarray.toString());
                                    textView.setText(jarray.toString());

                                    captureBtn.setEnabled(true);
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }

                            }
                        }, new Response.ErrorListener() {
                            @Override
                            public void onErrorResponse(VolleyError error) {
                                Toast.makeText(getApplicationContext(), "Error", Toast.LENGTH_LONG).show();
                            }
                        });
                    }
                });
            }
        });
    }

    @Override
    public void onPreviewFrame(byte[] bytes, Camera camera) {

    }

    @Override
    public void surfaceCreated(SurfaceHolder surfaceHolder) {
        try {
            camera = Camera.open(Camera.CameraInfo.CAMERA_FACING_BACK);

            Camera.Parameters parameters = camera.getParameters();
            parameters.setFocusMode(Camera.Parameters.FOCUS_MODE_CONTINUOUS_PICTURE);
            camera.setParameters(parameters);

            camera.setPreviewDisplay(surfaceHolder);
            camera.setDisplayOrientation(90);
            camera.setPreviewCallback(this);
            camera.startPreview();
        } catch (IOException exception) {
            camera.setPreviewCallback(null);
            camera.release();
            camera = null;
        }
    }

    @Override
    public void surfaceChanged(SurfaceHolder surfaceHolder, int i, int i1, int i2) {

    }

    @Override
    public void surfaceDestroyed(SurfaceHolder surfaceHolder) {
        camera.setPreviewCallback(null);
        camera.release();
        camera = null;
    }
}
*/
