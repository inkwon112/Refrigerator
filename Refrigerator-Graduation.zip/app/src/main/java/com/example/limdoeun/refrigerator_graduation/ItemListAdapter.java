package com.example.limdoeun.refrigerator_graduation;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.List;

/**
 * Created by Lim Do Eun on 2017-08-21.
 */

public class ItemListAdapter extends BaseAdapter {

    private Context context;
    private List<Item> ItemList;

    public ItemListAdapter(Context context, List<Item> itemList) {
        this.context = context;
        this.ItemList = itemList;
    }

    @Override
    public int getCount() {
        return ItemList.size();
    }

    @Override
    public Object getItem(int i) {
        return ItemList.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        View v = View.inflate(context, R.layout.item, null);
        TextView ItemText = (TextView) v.findViewById(R.id.itemText);
        TextView dateText = (TextView) v.findViewById(R.id.dateText);

        ItemText.setText(ItemList.get(i).getList());
        dateText.setText(ItemList.get(i).getDate());

        v.setTag(ItemList.get(i).getList());
        return v;

    }


}
