package com.example.limdoeun.refrigerator_graduation;

/**
 * Created by Lim Do Eun on 2017-08-21.
 */

public class Item {

    String list;
    String date;

    public Item(String list, String date) {
        this.list = list;
        this.date = date;
    }

    public String getList() {
        return list;
    }

    public void setList(String list) {
        this.list = list;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }
}
